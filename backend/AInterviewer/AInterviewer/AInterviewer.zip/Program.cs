using AInterviewer.Data;
using AInterviewer.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.AI;
using Microsoft.IdentityModel.Tokens;
using OpenAI;
using System.Security.Cryptography.X509Certificates;
using System.Text;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddOpenApi();

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters()
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))
    };
    options.Events = new JwtBearerEvents
    {
        OnMessageReceived = context =>
        {
            var accessToken = context.Request.Query["access_token"];
            var path = context.HttpContext.Request.Path;

            if (!string.IsNullOrEmpty(accessToken) && path.StartsWithSegments("/habs/yjsHab"))
            {
                context.Token = accessToken;
            }

            return Task.CompletedTask;
        }
    };
});
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseNpgsql(builder.Configuration["DefaultConnection:ConnectionString"]));

builder.Services.AddCors(options => {
    options.AddPolicy("CorsPolicy", policy =>
    {
        policy.WithOrigins(
                "http://localhost:12117",
                "https://localhost:12117",
                "http://localhost:8080",
                "https://localhost:8080",
                "https://ainterviewer.creanima.ra")
            .AllowAnyHeader()
            .AllowAnyMethod()
            .AllowCredentials();
    });
});

builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IInterviewService, InterviewService>();
builder.Services.AddScoped<IAiInterviewService, AiInterviewService>();


// ======== GPT integration ========
//var lmStudioUri = new Uri("http://host.docker.internal:1234/v1");
//var clientOptions = new OpenAIClientOptions { Endpoint = lmStudioUri };
////var openAIClient = new OpenAIClient(new System.ClientModel.ApiKeyCredential("sk-lm-mk3WYckb:sVT0NrCTOtgzLToNYU2i"), clientOptions);
//var openAIClient = new OpenAIClient(new System.ClientModel.ApiKeyCredential("AQVN1cYXCUHnuh6d1dqubjR457ZKHjmqd3nSq-fF"), clientOptions);
//builder.Services.AddSingleton<IChatClient>(sp =>
//    openAIClient.GetChatClient("google/gemma-4-e2b").AsIChatClient()
//);
// =================================
// ======== GPT integration ========

builder.Services.AddSingleton<IChatClient>(sp =>
{
    var httpClient = new HttpClient();

    return new YandexGptChatClient(
        httpClient,
        builder.Configuration["YandexGPT:ApiKey"]!,
        builder.Configuration["YandexGPT:FolderId"]!);
});

// =================================


var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.UseSwaggerUI(options=>
    {
        options.SwaggerEndpoint("/openapi/v1.json", "AInterviewer API");
    });
}

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

{
    using var scope = app.Services.CreateScope();
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    db.Database.Migrate();
}

app.Run();
